
export class Util {
let msgs =[] ;
msg = ["Creativity is like washing a pig",
"Nothing comes from nothing",
"Creativity is just connecting things",
"An idea can turn to dust or magic",
"Creative ideas flourish best in a shop which preserves some spirit of fun",
"If you have anything really valuable to contribute to the world",
"Creativity and innovation are about finding unexpected solutions to obvious problems",
"The best ideas come as jokes"];
let types=[];
types = ["Video","Post","Images","Audio","Link"];
let titles=[];
titles = ["Alert","Wishes","Shares","Information","Celebrations"];
static generateMsg() {
   return msg[Math.floor(Math.random()*msg.length)];
}
static generateType(){
return types[Math.floor(Math.random()*types.length)];
}
static generateTitle(){
return titles[Math.floor(Math.random()*titles.length)];
}
}
