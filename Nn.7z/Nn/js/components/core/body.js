import React from 'react';
import ReactDom from 'react-dom';
import PostContainer from '../app/postContainer'
export default class MainBody extends React.Component {
  render() {
    return(
      <div className="col-sm-6 text-left">
      <div>
      <div style={{position:'relative'}}>
       <PostContainer posts={this.props.propsList} />
      </div>
      </div>
      </div>
    );
  }
}
