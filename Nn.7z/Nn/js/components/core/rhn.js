import React from 'react';
import ReactDom from 'react-dom';
import { NavMenu } from './navigation'
export default class RHN extends React.Component {
  render() {
    return(
      <div className="col-sm-3" >
      <div className="collapse navbar-collapse" id="myNavbarRight">
      <NavMenu links={this.props.links} inline='true' />
      </div>
      </div>
    );
  }
}
