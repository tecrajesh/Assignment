import React from 'react';
import ReactDom from 'react-dom';
export default class Post extends React.Component {
  render() {
    //let type = this.props.type ? this.props.type : 'default';
    let bgColors = ["#81b71a","#00B1E1","#37BC9B","#8CC152","#E9573F","#F6BB42"];
    return(
      <div className="well well-sm" style={{backgroundColor: bgColors[Math.floor(Math.random()*bgColors.length)]}}>
      <h2 className="section-heading text-center">{this.props.postName}</h2>
      <p className="text-faded text-center">{this.props.message}</p>
      </div>
    );
  }
}
