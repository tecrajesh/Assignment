import React from 'react';
import ReactDom from 'react-dom';
import Post from './post';
export default class PostContainer extends React.Component {
  render() {
    var postList = this.props.posts.map(function(post){
      return (
        <span>
          <Post postName={post.name} message={post.massage} type={post.type} />
        </span>
        );
    });
    return(
      <div style={{height:'400px', overflow:'auto'}}>
        {postList}
      </div>
    );
  }
}
