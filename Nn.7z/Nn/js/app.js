import React from 'react';
import ReactDom from 'react-dom';
//import { Button } from react-bootstrap;
import { NavBar } from './components/core/navigation';
import LHN from './components/core/lhn';
import RHN from './components/core/rhn';
import MainBody from './components/core/body';
//import Util from './util/msgGenerator';
const msgs = ["Creativity is like washing a pig",
"Nothing comes from nothing",
"Creativity is just connecting things",
"An idea can turn to dust or magic",
"Creative ideas flourish best in a shop which preserves some spirit of fun",
"If you have anything really valuable to contribute to the world",
"Creativity and innovation are about finding unexpected solutions to obvious problems",
"The best ideas come as jokes"];
const types = ["Video","Post","Images","Audio","Link"];
const titles =["Alert","Wishes","Shares","Information","Celebrations"];
function generateMsg() {
  return msgs[Math.floor(Math.random()*msgs.length)];
}
function generateType(){
  return types[Math.floor(Math.random()*types.length)];
}
function generateTitle(){
  return titles[Math.floor(Math.random()*titles.length)];
}
let navbar = {};
navbar.brand =
  {linkTo: "#", text: "KooBecaF"};
navbar.links = [
  {linkTo: "#", text: "Home"},
  {linkTo: "#", text: "Friends"},
  {linkTo: "#", text: "Profile"},
  {linkTo: "#", text: "Settings"},
];
let lhnLinks = [];
lhnLinks.links = [
  {linkTo: "#", text: "Home"},
  {linkTo: "#", text: "Friends"},
  {linkTo: "#", text: "Profile"},
  {linkTo: "#", text: "Settings"},
];
let rhnLinks = [];
rhnLinks.links = [
  {linkTo: "#", text: "Products"},
  {linkTo: "#", text: "Services"},
  {linkTo: "#", text: "ContactUS"},
  {linkTo: "#", text: "Settings"},
];
let propsList=[];
propsList.propsList = [];
for(let i=0;i<50;i++) {
 const post = { name:generateTitle(),massage:generateMsg(),type:generateType()};
 propsList.propsList.push(post);
}

ReactDom.render(
  <NavBar {...navbar} />,
  document.getElementById("navbar")
);
ReactDom.render(
  <MainBody {...propsList} />,
  document.getElementById("bodypart")
);
ReactDom.render(
  <LHN {...lhnLinks} />,
  document.getElementById("lhnpart")
);
ReactDom.render(
  <RHN {...rhnLinks} />,
  document.getElementById("rhnpart")
);
